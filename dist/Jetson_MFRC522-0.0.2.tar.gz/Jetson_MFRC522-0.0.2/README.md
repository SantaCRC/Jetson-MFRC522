# RFID library for Jetson Family
This is a simple python library that provides a way to communicate jetson devices with MRFC522 modules
