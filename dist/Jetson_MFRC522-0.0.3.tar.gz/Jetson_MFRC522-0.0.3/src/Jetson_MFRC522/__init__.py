from .MFRC522 import MFRC522
from .SimpleMFRC522 import SimpleMFRC522

name = "mfrc522"
